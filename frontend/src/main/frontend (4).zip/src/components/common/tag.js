import styled from 'styled-components';
import axios from 'axios';
import { useState } from 'react';


const categories = [
  {
    name: "lodging",
    text: "Accommodation",
  },
  {
    name: "landmark",
    text: "Landmark",
  },
  {
    name: "festival",
    text: "Festival",
  },
  {
    name: "food",
    text: "Dining",
  },
  {
    name: "leports",
    text: "Leisure",
  },
  {
    name: "shopping",
    text: "Shopping",
  },
  {
    name: "culture",
    text: "Culture",
  },
];

const Tag = ({ }) => {


  const Tagbtn = styled.div`
  height: 28px;
  margin-left: 28px;
  margin-right: -10px;
  margin-top: 10px;

  float: left;

  border: 1px solid #77AEFC;
border-radius: 50px;
  clear: none;

  background-repeat: no-repeat;


  font-family: 'Pretendard';
  font-style: normal;
  font-weight: 0;
  font-size: 16px;
  line-height: 30px;

  word-break: break-word;
  margin-bottom: 24px;
  padding: 0 20px;
  background-color: ${props => props.checked ? 'white' : '#77aefc'};
color:  ${props => props.checked ? '#77aefc' : '#ffffff'};
`;


  const Tagplace = styled.div`
  float: left;
  width: calc(28.95vw - 68px);
  margin-top: 18px;
`;


  return (
    <Tagplace>
      {categories.map((c) => (
       
      <Tagbtn  >
      <input type="radio"style={{}} value={c.text}>
      </input>{c.name}
      </Tagbtn>
      ))}
     
      

      <hr style={{ float: 'left', marginLeft:'28px',height: '0px', width: '25vw' }} />
    </Tagplace>
  );
};
export default Tag;
