import styled from 'styled-components';
import axios from 'axios';

const Tagplace = styled.div`
  float: left;
  width: calc(28.95vw - 68px);
  margin-top: 18px;
`;

const Tagbtn = styled.button`
  height: 28px;
  margin-left: 28px;
  margin-top: 10px;

  border: 1px solid #77AEFC;
border-radius: 50px;
  clear: none;
  background-color: transparent;
  background-repeat: no-repeat;

  font-family: 'Pretendard';
  font-style: normal;
  font-weight: 400;
  font-size: 16px;
  line-height: 19px;
  color: #77aefc;
  word-break: break-word;
  margin-bottom: 24px;
  padding: 0 20px;
`;
const Tag = ({ item1 }) => {
  return (
    <Tagplace>
      <Tagbtn>adafafa</Tagbtn>
      <Tagbtn>adafafa</Tagbtn>
      <Tagbtn>adafafa</Tagbtn>
      <Tagbtn>adafafa</Tagbtn>
      <Tagbtn>adafafa</Tagbtn>      
      <Tagbtn>adafafa</Tagbtn>
      <Tagbtn>adafafa</Tagbtn>
      <Tagbtn>adafafa</Tagbtn>
      <Tagbtn>adafafa</Tagbtn>      
      <Tagbtn>adafafa</Tagbtn>      
      <Tagbtn>adafafa</Tagbtn>      
      <Tagbtn>adafafa</Tagbtn>      
      <Tagbtn>adafafa</Tagbtn>      
      <Tagbtn>adafafa</Tagbtn>

      <hr style={{ float: 'left', height: '0px', width: '25vw' }} />
    </Tagplace>
  );
};
export default Tag;
